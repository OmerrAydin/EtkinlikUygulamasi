package com.omeraydin.etkinlikprojesi.model

data class UserInformation(val mail: String, val name: String)
